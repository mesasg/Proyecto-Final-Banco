/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.json;

import com.google.gson.*;
/**
 *
 * @author saram
 */
public class JsonFiles {
    Gson gson = new Gson();
    Gson gson1 = new Gson();
    //String fileJson = //ulr;
            
}
